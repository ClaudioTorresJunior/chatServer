#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <termios.h>

#define BUFFSIZE 2048
#define NICKSIZE 20

/* Cores no terminal */
#define COR_1 1
#define COR_1_COD "\x1b\x5b\x33\x31\x3b\x31\x6d"
#define COR_1_COD_FECHA "\x1b\x5b\x30\x6d"

#define COR_2 2
#define COR_2_COD "\x1b\x5b\x33\x32\x3b\x31\x6d"
#define COR_2_COD_FECHA "\x1b\x5b\x30\x6d"
/*
RED		    "\x1b\x5b\x33\x31\x6d"
REDBOLD		"\x1b\x5b\x31\x3b\x33\x31\x6d"
GREEN		"\x1b\x5b\x33\x32\x6d"
GREENBOLD	"\x1b\x5b\x31\x3b\x33\x32\x6d"
*/

void Die(char *mess){ perror(mess); exit(1); }

/* Coloca cor na mensagem */
void print_cor(char *msg, int cor){
    switch(cor){
        case 0:
            printf("%s", msg);
            break;

        case COR_1:
            printf(COR_1_COD"%s"COR_1_COD_FECHA, msg);
            break;

        case COR_2:
            printf(COR_2_COD"%s"COR_2_COD_FECHA, msg);
            break;
    }
}

int main(int argc, char *argv[]){
	int i;
	int sock;
	struct sockaddr_in echoserver;

	char nick[NICKSIZE], mensagem[BUFFSIZE];

	fd_set select_set;
	/* Tempo esperado para o select */
	struct timeval select_time;
	/* Usados para nao precisar do enter para iniciar o chat */
    struct termios initial_settings, new_settings;

	if (argc != 4){
		fprintf(stderr, "USAGE: TCPecho <server_ip> <port> <nominho>\n");
		exit(1);
	}

	strncat(nick, argv[3], sizeof(nick));

	/* Create the TCP socket */
	if ((sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0){
		Die("Failed to create socket");
	}

	/* Construct the server sockaddr_in structure */
	memset(&echoserver, 0, sizeof(echoserver));       /* Clear struct */
	echoserver.sin_family = AF_INET;                  /* Internet/IP */
	echoserver.sin_addr.s_addr = inet_addr(argv[1]);  /* IP address */
	echoserver.sin_port = htons(atoi(argv[2]));       /* server port */

	/* Establish connection */
	if (connect(sock, (struct sockaddr *) &echoserver, sizeof(echoserver)) < 0){
		Die("Failed to connect with server");
	}

	/* Obtem configuracoes antigas do terminal */
    tcgetattr(0, &initial_settings);

    /* Seta novas configuracoes do terminal */
    new_settings = initial_settings;
    new_settings.c_lflag &= ~ICANON;
    new_settings.c_lflag &= ~ECHO;
    new_settings.c_lflag &= ~ISIG;
    new_settings.c_cc[VMIN] = 0;
    new_settings.c_cc[VTIME] = 0;

	/* Envia nick */
	send(sock, nick, strlen(nick), 0);

	while(1){
		/* Seta o socket em select */
		FD_ZERO(&select_set);
		FD_SET(sock, &select_set);

		/* Sem tempo de block para select. */
        select_time.tv_sec = 0;
        select_time.tv_usec = 0;

		if((i = select(FD_SETSIZE, &select_set, NULL, NULL, &select_time)) < 0){
			Die("Erro select");
		}
		/* se i > 0, tem algo no socket */
		if(i > 0){
			if(FD_ISSET(sock, &select_set)){
				int t;
				t = recv(sock, mensagem, sizeof(mensagem), 0);

				/* mostra a mensagem */
				mensagem[t] = '\0';
				print_cor(mensagem, COR_1);

				fflush(stdout);
			}
		}

		/* Leitura non-block em getchar(). */
		tcsetattr(0, TCSANOW, &new_settings);
		char ch = getchar();
		tcsetattr(0, TCSANOW, &initial_settings);

		if(ch == '\n'){
			print_cor("Enviar: ", COR_2);
			fgets(mensagem, sizeof(mensagem), stdin);

			/* sair sai do chat */
			if(strcmp(mensagem, "sair\n") == 0){
				break;
			}
			/* Envia mensagem pro server */
			if (send(sock, mensagem, strlen(mensagem), 0) < 0){
				Die("Mismatch in number of sent bytes");
			}
		}
	}
	close(sock);
	return 0;
}