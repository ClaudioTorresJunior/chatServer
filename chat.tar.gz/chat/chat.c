#include "chat.h"

void Die(char *mess) { perror(mess); exit(1); }

/* Limpa a estruct da lista de clientes */
void limpa_lista_clientes(struct cliente *c){
    memset(c->nick, 0, sizeof(c->nick));
    c->clientsock = -1;
    c->tem_nick = 0;
    c->esta_conectado = 0;
}

/*Insere sockets conectados em um vetor*/
char insere_socket(int socket){
    int i;

    if(sockets_salvos == MAXUSER){
        return 1;
    }

    for(i = 0; i < MAXUSER; i++){
        if(salva_sockets[i].clientsock == -1){
            salva_sockets[i].esta_conectado = 1;
            salva_sockets[i].clientsock = socket;
            sockets_salvos++;
            break;
        }
    }
    return 0;
}

/* Remove socket */
void remove_socket(int socket){
    int t;

    for(t = 0; t < MAXUSER; t++){
        if(salva_sockets[t].clientsock == socket){
            sprintf(client_message, "%s saiu do chat.\n", salva_sockets[t].nick);
            manda_msg(salva_sockets[t].clientsock, 1);
            close(salva_sockets[t].clientsock);
            limpa_lista_clientes(&salva_sockets[t]);
            sockets_salvos--;
            break;
        }
    }
}

/* Recebe mensagem do cliente */
char recebe_mensagem(int socket){
    int t;

    memset(client_message, 0x0, BUFFSIZE);
    t = recv(socket, client_message, BUFFSIZE, 0);

    if(t == 0){
        remove_socket(socket);
        return 1;
    }
    return 0;
}

/* Manda mensagem para quem esta conectado */
void manda_msg(int socket, int eh_mensagem){
    int t;
    struct cliente from;

    /* Ve quem esta mandando a mensagem */
    for(t = 0; t < MAXUSER; t++){
        if(salva_sockets[t].clientsock == socket){
            from = salva_sockets[t];
        }
    }

    for(t = 0; t < MAXUSER; t++){
        if((salva_sockets[t].clientsock != -1) && (salva_sockets[t].clientsock != socket) && (salva_sockets[t].clientsock != serversock)){
            if(eh_mensagem == 0){
                char enviar[BUFFSIZE + 1];
                snprintf(enviar, BUFFSIZE, "<%s> disse: %s", from.nick, client_message);
                send(salva_sockets[t].clientsock, enviar, strlen(enviar), 0);
            }else{
                send(salva_sockets[t].clientsock, client_message, strlen(client_message), 0);
            }
        }
    }
}