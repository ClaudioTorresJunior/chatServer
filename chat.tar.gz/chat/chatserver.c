#include "chat.h"

int main(int argc , char *argv[]){

    int i, t;
    struct sockaddr_in echoserver;

    struct timeval select_time;

    sockets_salvos = 0;

    if (argc != 2){
        printf("Falta porta\n");
        exit(1);
    }
     
    /* Cria socket */
    if((serversock = socket(PF_INET , SOCK_STREAM , IPPROTO_TCP)) < 0){
        Die("Falha ao criar socket");
    }

    /* Inicia a struct sockaddr_in do servidor */
    memset(&echoserver, 0, sizeof(echoserver)); /* Limpa a struct */
    echoserver.sin_family = AF_INET; /* Internet/IP */
    echoserver.sin_addr.s_addr = htonl(INADDR_ANY); /* Incoming addr */
    echoserver.sin_port = htons(atoi(argv[1])); /* Porta do servidor */
     
    /* Inicia socket em um endereço */
    if(bind(serversock,(struct sockaddr *)&echoserver , sizeof(echoserver)) < 0){
        Die("Falha ao iniciar o socket");
    }
     
    //Listen
    if(listen(serversock , MAXPENDING) < 0){
        Die("Falha ao escutar o socket");
    }
     
    
    //salvar sockets 
    salva_sockets = (struct cliente*)malloc(MAXUSER*sizeof(struct cliente));
    if(salva_sockets == NULL)
        Die("Erro ao alocar espaço");

    for(i = 0; i < MAXUSER; i++)
        limpa_lista_clientes(&salva_sockets[i]);
    
    while(1){
        /* Seta o socket em select */
        FD_ZERO(&select_set);
        FD_SET(serversock, &select_set);

        for(i = 0; sockets_salvos > 0 && i < MAXUSER; i++){
            if(salva_sockets[i].clientsock != -1){
                FD_SET(salva_sockets[i].clientsock, &select_set);
            }
        }

        select_time.tv_sec = 2;
        select_time.tv_usec = 0;

        if ((t = select(FD_SETSIZE, &select_set, NULL, NULL, &select_time)) < 0){
           Die("erro select");
        }

        if(t > 0){
            if(FD_ISSET(serversock, &select_set)){
                int n;
                if((n = accept(serversock, NULL, NULL)) < 0){
                    Die("Erro accept");
                }else if(insere_socket(n) == 1){
                    send(n, "TA CHEIO", 9, 8);
                    close(n);
                }
            }else{
                int j;
                for(j = 0; j < MAXUSER; j++){
                    if(FD_ISSET(salva_sockets[j].clientsock, &select_set)){
                        if(recebe_mensagem(salva_sockets[j].clientsock) == 0){
                            int eh_mensagem = 0;

                            if(salva_sockets[j].tem_nick == 0){ //salvando o nick
                                salva_sockets[j].tem_nick = 1;
                                strncpy(salva_sockets[j].nick, client_message, NICKSIZE);

                                if(salva_sockets[j].nick[strlen(salva_sockets[j].nick) - 1] == '\n'){
                                    salva_sockets[j].nick[strlen(salva_sockets[j].nick) - 1] = 0;
                                }
                                snprintf(client_message, BUFFSIZE, "%s : entrou no chat!\n", salva_sockets[j].nick);
                                eh_mensagem = 1;
                            }
                            manda_msg(salva_sockets[j].clientsock, eh_mensagem);
                        }
                    }
                }
                system("clear");
                printf("conectados: ");
                for (i = 0; i < MAXUSER; i++){
                    printf("%s ", salva_sockets[i].nick);
                }
                printf("\n");
            }
        }
    }
    return 0;
}