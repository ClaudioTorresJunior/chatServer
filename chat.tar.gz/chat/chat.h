#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h> /* Biblioteca contendo endereços de domínios da internet */
#include <sys/socket.h> /* Biblioteca contendo as definições de sockets */
#include <arpa/inet.h>  /* Biblioteca contendo funções referentes ao inet (rede) */
#include <sys/times.h>
#include <sys/select.h> 

#define MAXPENDING 3           /* Tamanho máximo da fila de conexões pendentes */
#define MAXUSER 5 
#define BUFFSIZE 2048 
#define NICKSIZE 20

struct cliente{
    char nick[NICKSIZE + 1];
    int clientsock;
    int tem_nick;
    int esta_conectado;
};

struct cliente *salva_sockets;

char client_message[BUFFSIZE + 1];
int sockets_salvos;
int serversock;

fd_set select_set;

void Die(char *mess);
void limpa_lista_clientes(struct cliente *c);
char insere_socket(int socket);
void remove_socket(int socket);
char recebe_mensagem(int socket);
void manda_msg(int socket, int eh_mensagem);